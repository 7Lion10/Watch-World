<div class="footer-area footer-padding">
            <div class="container">
                <div class="row d-flex justify-content-between">
                    <div class="col-xl-3 col-lg-3 col-md-5 col-sm-6">
                        <div class="single-footer-caption ">
                            <div class="single-footer-caption ">
                                <!-- logo -->
                                <!-- <div class="footer-logo">
                                    <a href="index.php"><img src="assets/img/logo/logo2_footer.png" alt=""></a>
                                </div> -->
                                
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-3 col-md-3 col-sm-5"style="color: red;">
                        <div class="single-footer-caption ">
                            <div class="footer-tittle" >
                                <h4 >Quick Links</h4>
                                <ul >
                                    <li><a href="index.php">Home </a></li>
                                    <li><a href="about.php">About</a></li>
                                    <li><a href="blog.php">Blog</a></li>
                                    <li><a href="feedback.php">Feedback</a></li>
                                    <li><a href="products.php">Products</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    
                </div>
                <!-- Footer bottom -->
                      
                
            </div>
        </div>