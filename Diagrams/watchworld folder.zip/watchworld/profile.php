<?php 
include 'config.php';
$admin = new Admin();
error_reporting(E_ALL & ~E_NOTICE);


?>

<!doctype html>
<html class="no-js" lang="zxx">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Watch shop | eCommers</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="manifest" href="site.webmanifest">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

    <!-- CSS here -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/flaticon.css">
    <link rel="stylesheet" href="assets/css/slicknav.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/slick.css">
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <link rel="stylesheet" href="assets/css/style.css">





</head>






<body>
    <!--? Preloader Start -->
    <div id="preloader-active">
        <div class="preloader d-flex align-items-center justify-content-center">
            <div class="preloader-inner position-relative">
                <div class="preloader-circle"></div>
                <div class="preloader-img pere-text">
                    <img src="assets/img/logo/logo.png" alt="">
                </div>
            </div>
        </div>
    </div>
    <!-- Preloader Start -->
    <header>
        <!-- Header Start -->
        <?php
        include 'header.php';
        $cid=$_SESSION['c_id'];
if(!isset($_SESSION['c_id'])){

    header('Location:login/login.php');

}

$st=$admin->ret("SELECT * FROM `customer` WHERE `c_id`='$cid'");
$ro=$st->fetch(PDO::FETCH_ASSOC);
    ?>
        
        <!-- Header End -->
    </header>
    <main>

<div class="col">
        <nav aria-label="breadcrumb" class="bg-light rounded-3 p-3 mb-4">
          <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="index.php"style="color: red;">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">User profile</li>
          </ol>
        </nav>
      </div>

        <div class="container">
    <div class="main-body">
        <div class="row">
    
   
  



<div class="col-lg-4 "style="color: gray !important;">
                <div class="card" >
                  <div class="card-body">
                    <div class="d-flex flex-column align-items-center text-center">
                      <img src="controller/<?php echo $ro['image']?>" alt="Admin" class="" width="110">
                      <div class="mt-3">
                        <h4><?php echo $ro['c_name']?></h4>
                        <p class="mb-1"><?php echo $ro['email']?></p>
                        <p class="font-size mb-1"><?php echo $ro['contact']?></p>
                        <p class="font-size-sm mb-1"><?php echo $ro['address']?></p>
                        
                      </div>
                    </div>
                    <hr class="" />
                    
                  </div>
                </div>
              </div>
              <div class="col-lg-8" style="color:blue">
                <div class="card">
                  <div class="card-body">
                    <h5 style="padding-bottom: 30px;color: #e70000">Edit profile</h5>

                    <form method="POST" action="controller/updateprofile.php">
                    <div class="row mb-3">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Full Name</h6>
                      </div>
                      <div class="col-sm-9">
                        <input type="text" class="form-control" value="<?php echo $ro['c_name']?>" name="fullname" />
                      </div>
                    </div>
                    <div class="row mb-3">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Email</h6>
                      </div>
                      <div class="col-sm-9">
                        <input type="text" class="form-control" value="<?php echo $ro['email']?>" name="email"/>
                      </div>
                    </div>
                    <div class="row mb-3">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Phone</h6>
                      </div>
                      <div class="col-sm-9">
                        <input type="text" class="form-control" value="<?php echo $ro['contact']?>" name="contact"/>
                      </div>
                    </div>
                    
                    <div class="row mb-3">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Address</h6>
                      </div>
                      <div class="col-sm-9">
                        <input type="text" class="form-control" value="<?php echo $ro['address']?>" name="address"/>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-sm-3"></div>
                      <div class="col-sm-9">
                        <input type="submit" name="edit" class="btn btn-danger px-4" value="Save Changes" onclick="return confirm('Are you sure??????');">
                      </div>
                    </div>
                  </form>
                  </div>
                </div>
                
              </div>


</div>
        </div>
    </div>

        
    </main>
    <footer>
        <!-- Footer Start-->
        <?php
        include 'footer.php';
    ?>
        
        <!-- Footer End-->
    </footer>
    <!--? Search model Begin -->
    <div class="search-model-box">
        <div class="h-100 d-flex align-items-center justify-content-center">
            <div class="search-close-btn">+</div>
            <form class="search-model-form">
                <input type="text" id="search-input" placeholder="Searching key.....">
            </form>
        </div>
    </div>
    <!-- Search model end -->

    <!-- JS here -->

    <script src="./assets/js/vendor/modernizr-3.5.0.min.js"></script>
    <!-- Jquery, Popper, Bootstrap -->
    <script src="./assets/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="./assets/js/popper.min.js"></script>
    <script src="./assets/js/bootstrap.min.js"></script>
    <!-- Jquery Mobile Menu -->
    <script src="./assets/js/jquery.slicknav.min.js"></script>

    <!-- Jquery Slick , Owl-Carousel Plugins -->
    <script src="./assets/js/owl.carousel.min.js"></script>
    <script src="./assets/js/slick.min.js"></script>

    <!-- One Page, Animated-HeadLin -->
    <script src="./assets/js/wow.min.js"></script>
    <script src="./assets/js/animated.headline.js"></script>
    <script src="./assets/js/jquery.magnific-popup.js"></script>

    <!-- Scrollup, nice-select, sticky -->
    <script src="./assets/js/jquery.scrollUp.min.js"></script>
    <script src="./assets/js/jquery.nice-select.min.js"></script>
    <script src="./assets/js/jquery.sticky.js"></script>
    
    <!-- contact js -->
    <script src="./assets/js/contact.js"></script>
    <script src="./assets/js/jquery.form.js"></script>
    <script src="./assets/js/jquery.validate.min.js"></script>
    <script src="./assets/js/mail-script.js"></script>
    <script src="./assets/js/jquery.ajaxchimp.min.js"></script>
    
    <!-- Jquery Plugins, main Jquery -->    
    <script src="./assets/js/plugins.js"></script>
    <script src="./assets/js/main.js"></script>
    
</body>
</html>