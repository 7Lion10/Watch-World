<?php 
include 'config.php';
$admin = new Admin();
error_reporting(E_ALL & ~E_NOTICE);

$cid=$_SESSION['c_id'];
?>


<!doctype html>
<html class="no-js" lang="zxx">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Watch shop | eCommers</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="manifest" href="site.webmanifest">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

    <!-- CSS here -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/flaticon.css">
    <link rel="stylesheet" href="assets/css/slicknav.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/slick.css">
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <link rel="stylesheet" href="assets/css/style.css">



<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Open+Sans">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<!-- end -->
<style type="text/css">
  
</style>


</head>






<body>
    <!--? Preloader Start -->
    <div id="preloader-active">
        <div class="preloader d-flex align-items-center justify-content-center">
            <div class="preloader-inner position-relative">
                <div class="preloader-circle"></div>
                <div class="preloader-img pere-text">
                    <img src="assets/img/logo/logo.png" alt="">
                </div>
            </div>
        </div>
    </div>
    <!-- Preloader Start -->
    <header>
        <!-- Header Start -->
        <?php
        include 'header.php';
        $id=$_SESSION['c_id'];
if(!isset($_SESSION['c_id'])){

    header('Location:login/login.php');

}
    ?>
        
        <!-- Header End -->
    </header>
    <main>


<section>
        <div class="container">
            <div class="row">

<div class="container">
  <div class="py-5 text-center">
    
    <h2>Checkout form</h2>
  
  </div>

  <div class="row">
    <div class="col-md-4 order-md-2 mb-4">
        <?php 
             $gtotal=0;
            $st=$admin->ret("SELECT * FROM `cart` INNER JOIN `products` ON cart.p_id=products.p_id WHERE `c_id`='$cid'");
            $num=$st->rowCount()?>
            

      <h4 class="d-flex justify-content-between align-items-center mb-3">
        <span class="text-muted">Your cart</span>
        <span class="badge badge-secondary badge-pill"><?php echo $num?></span>
      </h4>
      <ul class="list-group mb-3">
       <?php  while( $ro=$st->fetch(PDO::FETCH_ASSOC)){?>

        <li class="list-group-item d-flex justify-content-between lh-condensed">
          <div>
            <h6 class="my-0"><?php echo $ro['p_name']?></h6>
            <!-- <small class="text-muted"><?php echo $ro['p_description']?></small> -->
          </div>
          <!-- <span class="text-muted">₹<?php echo $ro['p_price']?></span> -->
          <!-- <span class="text-muted"><?php echo $ro['quantity']?> Piece</span> -->
        ₹<?php echo $total=$ro['quantity']*$ro['p_price']?>
        </li>
    <?php 

$gtotal=$gtotal+$total;
} ?>
<br><br>
    <div class="order-total">
     <h5 style="margin-left: 160px">Order total <span>₹<?php echo $gtotal?></span></h5>
    </div>
       
        
      </ul>

      
    </div>
    <div class="col-md-8 order-md-1">
      <h4 class="mb-3">Billing address</h4>
      <form class="needs-validation" action="controller/order_pay.php" method="POST">
        <div class="row">
          <div class="col-md-6 mb-3">
            <label for="firstName">First name</label>
            <input type="text" class="form-control" id="firstName" placeholder="" name="f_name"pattern="[a-zA-Z'-'\s]*" title="Must contain only alphabets " required>
           
          </div>
          <div class="col-md-6 mb-3">
            <label for="lastName">Last name</label>
            <input type="text" class="form-control" id="lastName" placeholder="" name="l_name"pattern="[a-zA-Z'-'\s]*" title="Must contain only alphabets " required>
            
          </div>
        </div>

       

        

        <div class="mb-3">
          <label for="address">Address</label>
          <input type="text" class="form-control" id="address" placeholder="Address" name="addrs1" required>
          <div class="invalid-feedback">
            Please enter your shipping address.
          </div>
        </div>

        <div class="mb-3">
          <label for="address2">Address 2 <span class="text-muted">(Optional)</span></label>
          <input type="text" class="form-control" id="address2" placeholder="Address2" name="addrs2">
        </div>

       <div class="row">
        <div class="col-md-4 mb-3">
            <label for="firstName">Contact</label>
            <input type="text" class="form-control" id="firstName" placeholder="Contact" name="contact"pattern="[1-9]{1}[0-9]{9}"title="Must contain 10 digit numbers" required>
            
          </div>
          <div class="col-md-4 mb-3">
            <label for="firstName">State</label>
            <input type="text" class="form-control" id="firstName" placeholder="State" name="state"pattern="[a-zA-Z'-'\s]*" title="Must contain only alphabets " required>
            
          </div>
          <div class="col-md-4 mb-3">
            <label for="lastName">Pin Code</label>
            <input type="text" class="form-control" id="lastName" placeholder="Pincode" name="pincode" pattern="[1-9]{1}[0-9]{5}"title="Must contain 6 digit numbers for pincode!"required>
            
          </div>
        </div>

        <hr class="mb-4">
                <h4 class="mb-3">Payment</h4>

        <div class="payment-methods">
                            <div class="Pement">
              
                                
                            </div>
                            <div class="card-info pt-40 ">

                                
                                <br>
                                

                                <input type="radio" name="payment_method" value="upi" id="upi" onclick="cardform(this.value)">&nbsp;
                                <label style="font-family: 'Open Sans', sans-serif;">UPI / Netbanking</label>
                                <div style="display:none;" id="upi_div">

                                    <div class="Pement">
                                    <div class="form-box">
                                        <label>Scan and Pay</label>
                                        <img src="assets/img/gallery/qr.png" height="100px" width="100px">
                                        
                                    </div>
                                    <br>
                                    <div class="form-box">
                                        <label>Trans / Id</label>
                                        <input type="text" name="transaction" placeholder="0000 0000 0000 0000 "pattern="[1-9]{1}[0-9]{15}"title="Must contain 16 digit numbers!">

                                        
                                    </div>
                                </div>
                                    
                                    
                                </div><br>

                                <input type="radio" name="payment_method" value="card" id="card" onclick="cardform(this.value)">&nbsp;
                                <label style="font-family: 'Open Sans', sans-serif;padding-bottom: 15px;">Debit Card / Credit Card</label><br>
                                <div style="display:none;" id="card_div">
                                    <div class="form-box">
                                        <label>Card No</label>
                                        <input  type="text" placeholder="0000 0000 0000 0000 "pattern="[1-9]{1}[0-9]{15}"title="Must contain 16 digit numbers!" name="card_no">
                                    </div>
                                    <div class="form-box">
                                        <label>Expiry</label>
                                        <input type="text" placeholder="MM / YY" minlength="5" maxlength="5" name="expiry">
                                    </div>
                                    
                                </div>

                                
                                    
                                
                            </div>
                        </div>

                        <div class="col-md-12">
                    <div class="order-btn text-center mt-30">
                        <input type="hidden" value="<?php echo $gtotal?>" name="total_amt">

                        <input type="hidden" value="<?php echo $cid?>" name="user_id">

                      


                        <input type="submit" value="Place Order" class="order-btn text-center mt-30"style="background-color:#ff2020;color:white;padding: 10px; border-radius: 10px;border: 1px solid white;">
                    </div>
                </div>

      </form>
    </div>
  </div>


</div>
            
                





                
            </div>
        </div>
    </section>       

        
    </main>
    <footer>
        <!-- Footer Start-->
        <?php
        include 'footer.php';
    ?>
        
        <!-- Footer End-->
    </footer>
    <!--? Search model Begin -->
    <div class="search-model-box">
        <div class="h-100 d-flex align-items-center justify-content-center">
            <div class="search-close-btn">+</div>
            <form class="search-model-form">
                <input type="text" id="search-input" placeholder="Searching key.....">
            </form>
        </div>
    </div>
    <!-- Search model end -->

    <!-- JS here -->

    <script>
    
        function cardform(myvalue) {

            if (myvalue == 'card') { //radio button id
                document.getElementById('card_div').style.display = 'block'; //div id
                document.getElementById('upi_div').style.display = 'none';
                document.getElementById('cash_div').style.display = 'none';

            } else if(myvalue == 'upi') {
                document.getElementById('card_div').style.display = 'none';
                document.getElementById('upi_div').style.display = 'block';
                document.getElementById('cash_div').style.display = 'none';
            } else {
                document.getElementById('card_div').style.display = 'none';
                document.getElementById('upi_div').style.display = 'none';
                document.getElementById('cash_div').style.display = 'block';
            }

        }
        
    
</script>
    


    <script src="./assets/js/vendor/modernizr-3.5.0.min.js"></script>
    <!-- Jquery, Popper, Bootstrap -->
    <script src="./assets/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="./assets/js/popper.min.js"></script>
    <script src="./assets/js/bootstrap.min.js"></script>
    <!-- Jquery Mobile Menu -->
    <script src="./assets/js/jquery.slicknav.min.js"></script>

    <!-- Jquery Slick , Owl-Carousel Plugins -->
    <script src="./assets/js/owl.carousel.min.js"></script>
    <script src="./assets/js/slick.min.js"></script>

    <!-- One Page, Animated-HeadLin -->
    <script src="./assets/js/wow.min.js"></script>
    <script src="./assets/js/animated.headline.js"></script>
    <script src="./assets/js/jquery.magnific-popup.js"></script>

    <!-- Scrollup, nice-select, sticky -->
    <script src="./assets/js/jquery.scrollUp.min.js"></script>
    <script src="./assets/js/jquery.nice-select.min.js"></script>
    <script src="./assets/js/jquery.sticky.js"></script>
    
    <!-- contact js -->
    <script src="./assets/js/contact.js"></script>
    <script src="./assets/js/jquery.form.js"></script>
    <script src="./assets/js/jquery.validate.min.js"></script>
    <script src="./assets/js/mail-script.js"></script>
    <script src="./assets/js/jquery.ajaxchimp.min.js"></script>
    
    <!-- Jquery Plugins, main Jquery -->    
    <script src="./assets/js/plugins.js"></script>
    <script src="./assets/js/main.js"></script>
    
</body>
</html>