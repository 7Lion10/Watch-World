<?php 
include 'config.php';
$admin = new Admin();
error_reporting(E_ALL & ~E_NOTICE);


?>

<!doctype html>
<html class="no-js" lang="zxx">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Watch shop | eCommers</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="manifest" href="site.webmanifest">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

    <!-- CSS here -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/flaticon.css">
        <link rel="stylesheet" href="assets/css/slicknav.css">
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <link rel="stylesheet" href="assets/css/magnific-popup.css">
        <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
        <link rel="stylesheet" href="assets/css/themify-icons.css">
        <link rel="stylesheet" href="assets/css/slick.css">
        <link rel="stylesheet" href="assets/css/nice-select.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <style type="text/css">
            .link-muted { color: #aaa; } .link-muted:hover { color: #1266f1; }
        <!-- </style>

</head>

<body>
    <!--? Preloader Start -->
    <div id="preloader-active">
        <div class="preloader d-flex align-items-center justify-content-center">
            <div class="preloader-inner position-relative">
                <div class="preloader-circle"></div>
                <div class="preloader-img pere-text">
                    <img src="assets/img/logo/logo.png" alt="">
                </div>
            </div>
        </div>
    </div>
    <!-- Preloader Start -->
    <header>
        <!-- Header Start -->
        <?php
        include 'header.php';
        $id=$_SESSION['c_id'];
if(!isset($_SESSION['c_id'])){

    header('Location:login/login.php');

}
    ?>
        <!-- Header End -->
    </header>
    <main>
        <!--? Hero Area Start-->
        <div class="col">
        <nav aria-label="breadcrumb" class="bg-light rounded-3 p-3 mb-4">
          <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="index.php"style="color: red;">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Feedbacks</li>
          </ol>
        </nav>
      </div>
        <!--? Hero Area End-->
        <!-- ================ contact section start ================= -->

        
        
        <section style="background-color: #ebebeb;">
  <div class="container my-5 py-5">
    <div class="row d-flex justify-content-start">
      <!-- <div class="col-md-12 col-lg-10"> -->
        <div class="card text-dark">
          <div class="card-body p-4"style="width: 1080px;">
            <!-- <h4 class="mx-auto" style="height: 50px;font-size:x-large;"><u>Feedbacks</u></h4> -->
            <!-- <p class="fw-light mb-4 pb-2">Latest Comments section by users</p> -->


            <?php
    $stmt=$admin->ret("SELECT * FROM `feedback`  ");

    while ($row=$stmt->fetch(PDO::FETCH_ASSOC)) {
        ?>
            <div class="d-flex flex-start"style="border: 1px solid #dddddd;padding: 5px;box-shadow: 6px 10px 5px #d5d5d5;"><i class="fa fa-user-circle"style="margin-top: 30px;">&nbsp; </i>
                
              <!-- <img class="rounded-circle shadow-1-strong me-3"
                src="" > -->
                
              <div style="margin-bottom: 50px;">
                <h6 class="fw-bold mb-1" style="color:red; font-size: larger;margin-top: 30px;"><?php echo $row['name']?></h6>
                <div class="d-flex align-items-center mb-3">
                  <p class="mb-auto" style="font-size: small;">
                    <?php echo $row['date']?>
                    
                  </p>
                  
                </div>
                <p style="font-size: 21px;color: #545454; ;"><strong><?php echo $row['subject']?></strong></p>
                <p class="mb-0" style="color:#484848;">
                  <?php echo $row['message']?>
                </p>
              </div>

            </div>
            <?php
    }
    ?> 
          </div>
          

          
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


        <section class="contact-section" style="margin-left:50px !important;">
            
                <div class="row">
                    <div class="col-12">
                        <h2 class="contact-title">Send feedback</h2>
                    </div>

                    
                    <div class="col-lg-8">

                        <form class="form-contact contact_form" action="controller/feedbackfile.php" method="post" >
                            <input class="form-control valid" name="cid" id="name" type="hidden" onfocus="this.placeholder = ''" value="<?php echo $id ?>"required>
                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group">
                                        <textarea class="form-control w-100" name="message" id="message" cols="30" rows="9" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Message'" placeholder=" Enter Message"required ></textarea>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <input class="form-control valid" name="name" id="name" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter your name'" placeholder="Enter your name"required>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <input class="form-control valid" name="email" id="email" type="email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter email address'" placeholder="Email"required>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                        <input class="form-control" name="subject" id="subject" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Subject'" placeholder="Enter Subject"required>
                                    </div>
                                
                            </div>
                            <div class="form-group mt-3">
                                <button type="submit" class="button button-contactForm boxed-btn">Send</button>
                            </div>
                        </form>
                    </div>
                    
                </div>
            
        </section>
        <!-- ================ contact section end ================= -->
    </main>
    <footer>
        <!-- Footer Start-->
        <?php
        include 'footer.php';
    ?>
        <!-- Footer End-->
    </footer>
    <!--? Search model Begin -->
    <div class="search-model-box">
        <div class="h-100 d-flex align-items-center justify-content-center">
            <div class="search-close-btn">+</div>
            <form class="search-model-form">
                <input type="text" id="search-input" placeholder="Searching key.....">
            </form>
        </div>
    </div>
    <!-- Search model end -->

    <!-- JS here -->
	
    <script src="./assets/js/vendor/modernizr-3.5.0.min.js"></script>
    <!-- Jquery, Popper, Bootstrap -->
    <script src="./assets/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="./assets/js/popper.min.js"></script>
    <script src="./assets/js/bootstrap.min.js"></script>
    <!-- Jquery Mobile Menu -->
    <script src="./assets/js/jquery.slicknav.min.js"></script>

    <!-- Jquery Slick , Owl-Carousel Plugins -->
    <script src="./assets/js/owl.carousel.min.js"></script>
    <script src="./assets/js/slick.min.js"></script>
    
    <!-- One Page, Animated-HeadLin -->
    <script src="./assets/js/wow.min.js"></script>
    <script src="./assets/js/animated.headline.js"></script>
    
    <!-- Scroll up, nice-select, sticky -->
    <script src="./assets/js/jquery.scrollUp.min.js"></script>
    <script src="./assets/js/jquery.nice-select.min.js"></script>
    <script src="./assets/js/jquery.sticky.js"></script>
    <script src="./assets/js/jquery.magnific-popup.js"></script>

    <!-- contact js -->
    <script src="./assets/js/contact.js"></script>
    <script src="./assets/js/jquery.form.js"></script>
    <script src="./assets/js/jquery.validate.min.js"></script>
    <script src="./assets/js/mail-script.js"></script>
    <script src="./assets/js/jquery.ajaxchimp.min.js"></script>
    
    <!-- Jquery Plugins, main Jquery -->	
    <script src="./assets/js/plugins.js"></script>
    <script src="./assets/js/main.js"></script>
        
</body>

</html>