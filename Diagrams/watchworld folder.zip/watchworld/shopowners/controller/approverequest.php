<?php
include '../config.php';
$admin =new Admin();
$id=$_GET['id'];
$stmt =$admin->cud("UPDATE `requests` SET `r_status`='approved' WHERE `r_id`='$id'","Deleted"); 
echo "<script>alert('Approved');window.location='../viewrequests.php';</script>";








?>