<?php 
include '../config.php';
$Admin = new Admin();

    $name =$_POST['name'];
    $price =$_POST['price'];
    $description =$_POST['des'];

   


   


    
    $stmt=$Admin->cud("INSERT INTO `service` (`s_name`,`s_price`,`s_description`)
        VALUES('$name','$price','".addslashes($description)."')","Saved");


     echo "<script>alert('Added successfully');window.location='../viewservices.php';</script>/";

?>