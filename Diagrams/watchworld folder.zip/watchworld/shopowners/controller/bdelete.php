<?php
include '../../config.php';
$admin =new Admin();
$id=$_GET['id'];
$stmt =$admin->cud("DELETE FROM `products` WHERE `p_id`='$id'","Deleted"); 
echo "<script>alert('Deleted successfully');window.location='../viewproducts.php';</script>";








?>