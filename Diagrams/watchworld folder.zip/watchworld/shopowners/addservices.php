<?php
include 'config.php';
$admin = new Admin();
error_reporting(E_ALL & ~E_NOTICE);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>DarkPan - Bootstrap 5 Admin Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet"> 
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <style type="text/css">
        .pars {
    /* this is used to prevent the last floating element 
    from causing issues below the paragraph (.pars) container */
    width: 100%;
    overflow: visible;
}
.pars p {
    clear: left;
    margin: 0 0 0.5em 0;
}
.pars .highlighted {
    float: left;
    padding: 5px;
    border-style: groove;
    border-width: 1px;
    background-color: #191C24;
    border-color:#ff0000;
}
div.pars{
  position:relative;
  top: 8px;
  left: 21px;
}
    </style>
    <div class="container-fluid position-relative d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-dark position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->



        <!-- Sidebar Start -->
        <?php
        include 'sidebar.php';
    ?>
        <!-- Sidebar End -->


        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
            <?php
        include 'header.php';
    ?>
            <!-- Navbar End -->


<div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-6">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h6 class="mb-4">Add Services</h6>
                            <form action="controller/addservicefile.php" method="post" enctype="multipart/form-data">
                                <div class="row mb-3">
                                    <label for="inputPassword3" class="col-sm-3 col-form-label">Name&nbsp;</label><br>
                                    <div class="col-sm-10">
                                        <input name="name" type="text" class="form-control" id="inputPassword3"maxlength="250" required>
                                    </div>
                                </div>
                                
                                <div class="row mb-3">
                                    <label for="inputPassword3" class="col-sm-3 col-form-label">Price&nbsp;</label><br>
                                    <div class="col-sm-10">
                                        <input name="price" type="text" class="form-control" id="inputPassword3"required>
                                    </div>
                                </div>
                                
                                <div class="row mb-3">
                                    <label for="inputPassword3" class="col-sm-3 col-form-label">Description&nbsp;</label><br>
                                    <div class="col-sm-10">
                                        <textarea name="des" type="text" class="form-control" id="inputPassword3"required rows="8"></textarea>
                                    </div>
                                </div>
                                
                                <button type="submit" class="btn btn-primary">Upload</button>
                                <!-- <div class="pars">
   <p class="highlighted"><strong>Note: </strong>If u need to put apostrophe/single quote in name or description,You'll have to put two apostrophe<br>(eg: Men' 's Watch, so it'll display as Men's Watch )</p>
</div> -->
                            </form>
                        </div>
                    </div>




            <!-- Sale & Revenue End -->


            <!-- Footer Start -->
            <?php
        include 'footer.php';
    ?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/chart/chart.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>