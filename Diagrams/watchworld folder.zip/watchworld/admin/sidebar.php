<div class="sidebar pe-4 pb-3">
            <nav class="navbar bg-secondary navbar-dark">
                <a href="#" class="navbar-brand mx-4 mb-3" ><img src="img/logo/logo.png" alt="">
                    <!-- <h3 class="text-primary"><i class="fa fa-user-edit me-2"></i>DarkPan</h3> -->

                </a>
                 
                
                <div class="navbar-nav w-100">
                    <a href="index.php" class="nav-item nav-link"><i class="fa fa-tachometer-alt me-2"></i>Dashboard</a>
                    <a href="mgshops.php" class="nav-item nav-link"><i class="fas fa-store fa"></i> &nbsp;Manage Shops</a>
                    <a href="mgusers.php" class="nav-item nav-link"><i class="fa fa-users"></i> &nbsp;View Customers</a>
                    <a href="mgorders.php" class="nav-item nav-link"><i class="fa fa-list-alt"></i> &nbsp;Order Details</a>
                    <a href="viewfeedback.php" class="nav-item nav-link"><i class="fa fa-comments"></i> &nbsp;View Feedback</a>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="fa fa-rss-square"></i> &nbsp;Blogs</a>
                        <div class="dropdown-menu bg-transparent border-0">
                            <a href="viewblog.php" class="dropdown-item">View</a>
                            <a href="upload.php" class="dropdown-item">Upload</a>
                        
                        </div>
                    </div>
                        
                    </div>
                </div>
            </nav>
        </div>