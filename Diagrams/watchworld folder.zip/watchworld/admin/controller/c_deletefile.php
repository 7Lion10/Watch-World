<?php
include '../../config.php';
$admin =new Admin();
$id=$_GET['id'];
$stmt =$admin->cud("DELETE FROM `customer` WHERE `c_id`='$id'","Deleted"); 
echo "<script>alert('Deleted successfully');window.location='../mgusers.php';</script>";








?>