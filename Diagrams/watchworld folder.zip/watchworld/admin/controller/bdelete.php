<?php
include '../../config.php';
$admin =new Admin();
$id=$_GET['id'];
$stmt =$admin->cud("DELETE FROM `blog` WHERE `bl_id`='$id'","Deleted"); 
echo "<script>alert('Deleted successfully');window.location='../viewblog.php';</script>";








?>