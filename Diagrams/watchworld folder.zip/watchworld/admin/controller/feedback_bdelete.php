<?php
include '../../config.php';
$admin =new Admin();
$id=$_GET['id'];
$stmt =$admin->cud("DELETE FROM `feedback` WHERE `f_id`='$id'","Deleted"); 
echo "<script>alert('Deleted successfully');window.location='../viewfeedback.php';</script>";








?>