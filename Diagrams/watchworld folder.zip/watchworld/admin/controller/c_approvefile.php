<?php
include '../../config.php';
$admin =new Admin();
$id=$_GET['id'];
$stmt =$admin->cud("UPDATE `customer` SET `status`='approved' WHERE `c_id`='$id'","Deleted"); 
echo "<script>alert('Approved');window.location='../mgusers.php';</script>";













?>