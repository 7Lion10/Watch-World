<?php
include '../../config.php';
$admin =new Admin();
$id=$_GET['id'];
$stmt =$admin->cud("DELETE FROM `shopowner` WHERE `s_id`='$id'","Deleted"); 
echo "<script>alert('Deleted successfully');window.location='../mgshops.php';</script>";








?>