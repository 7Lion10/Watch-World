<?php
include '../../config.php';
$admin =new Admin();
$id=$_GET['id'];
$stmt =$admin->cud("UPDATE `shopowner` SET `status`='approved' WHERE `s_id`='$id'","Deleted"); 
echo "<script>alert('Approved');window.location='../mgshops.php';</script>";








?>