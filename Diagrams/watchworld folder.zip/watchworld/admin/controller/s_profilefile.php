<?php
include '../../config.php';
$admin =new Admin();
$id=$_GET['c_id'];
$username=$_GET['username'];
$stmt=$admin->ret("SELECT  `username`, `image` FROM `customer`");

?>