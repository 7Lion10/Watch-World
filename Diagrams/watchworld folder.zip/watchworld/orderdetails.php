<?php 
include 'config.php';
$admin = new Admin();
error_reporting(E_ALL & ~E_NOTICE);

$cid=$_SESSION['c_id'];


$id=$_GET['id'];

$stmt=$admin->ret("SELECT * FROM `orders` WHERE `c_id`='$cid' AND `o_id`='$id'");
$row=$stmt->fetch(PDO::FETCH_ASSOC);
?>


<!doctype html>
<html class="no-js" lang="zxx">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Watch shop | eCommers</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="manifest" href="site.webmanifest">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

    <!-- CSS here -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/flaticon.css">
    <link rel="stylesheet" href="assets/css/slicknav.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/slick.css">
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <link rel="stylesheet" href="assets/css/style.css">



<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Open+Sans">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<!-- end -->
<style type="text/css">
  
</style>


</head>






<body>
    <!--? Preloader Start -->
    <div id="preloader-active">
        <div class="preloader d-flex align-items-center justify-content-center">
            <div class="preloader-inner position-relative">
                <div class="preloader-circle"></div>
                <div class="preloader-img pere-text">
                    <img src="assets/img/logo/logo.png" alt="">
                </div>
            </div>
        </div>
    </div>
    <!-- Preloader Start -->
    <header>
        <!-- Header Start -->
        <?php
        include 'header.php';
if(!isset($_SESSION['c_id'])){

    header('Location:login/login.php');

}
    ?>
        
        <!-- Header End -->
    </header>
    <main>


<section>
        <div class="container">
            <div class="row">


                





            <div class="col-md-6" style="background-color: #A9A9A9">
                                                <div class="text-gray-light">INVOICE TO:</div>
                                                <h2 class="to"><?php echo $row['f_name']?> <?php echo $row['l_name']?></h2>
                                                <div class="address"><?php echo $row['addrs1']?></div>
                                                <div class="address"><?php echo $row['contact']?></div>
                                                <div class="address"><?php echo $row['state']?></div>
                                                <div class="address"><?php echo $row['pincode']?></div>
                                                <!-- <div class="email"><a href="mailto:john@example.com"><?php echo $row['d_email']?></a>
                                                </div> -->
                                            </div>
                                            <div class="col-md-6" style="background-color: #A9A9A9" style="float:right">
                                                <h1 class="invoice-id">INVOICE <?php echo $row['o_id']?></h1>
                                                <div class="date">Date of Invoice: <?php echo $row['date']?></div>
                                                <!-- <div class="date">Due Date: 30/10/2018</div> -->
                                            </div>
                                        </div>
                                        <!-- tbale here-->
                                        <div class="row">
                <table class="table align-middle mb-0" style="background-color: #A9A9A9">
                                    <thead class="table-light" style="background-color:  #EBF4FA">
                                        <tr>
                                            <th>#</th>
                                            <th>Product</th>
                                            <th>Description</th>
                                            <th>Quantity</th>
                                            <th>Unit Price</th>
                                            <th>Total</th>
                                            
                                          

                                            
                                            
                                        </tr>
                                    </thead>
                                    <tbody >
                                        <?php 
                                        
                                        $stm=$admin->ret("SELECT * FROM `order_details` INNER JOIN `products` ON order_details.p_id=products.p_id WHERE `o_id`='$id'");
                                        while($r=$stm->fetch(PDO::FETCH_ASSOC)){
                                            ?>
                                            <tr>
                                                <td><?php echo $r['od_id']?><br>
                                                    <td><?php echo $r['p_name']?></td>
                                                
                                                
                                                <td><?php echo $r['p_description']?></td>
                                                <td><?php echo $r['quantity']?></td>
                                                <td><?php echo $r['p_price']?></td>
                                                <td>₹<?php echo $r['p_price']*$r['quantity']?></td>

                                                
                                              


                                                
                                            </tr>
                                            <?php 

                                            



                                        }?>
                                        
                                        
                                    </tbody>
                                </table>
            </div>
                                        <!--table ends here -->
                                        <br>
                                        <br>
                                        <br><br>
                                        <br><br>
                                        <div class="" style="text-align: center;">Thank you!</div>
                                        <!-- <div class="notices">
                                            <div>NOTICE:</div>
                                            <div class="notice">A finance charge of 1.5% will be made on unpaid balances after 30 days.</div>
                                        </div> -->
                                    </main>
                                    <br>
                                    <br>
                                    <footer><center>Invoice was created on a computer and is valid without the signature and seal.</center></footer>
                                </div>



                
            </div>
        </div>
    </section>       

        
    </main>
    <footer>
        <!-- Footer Start-->
        <?php
        include 'footer.php';
    ?>
        
        <!-- Footer End-->
    </footer>
    <!--? Search model Begin -->
    <div class="search-model-box">
        <div class="h-100 d-flex align-items-center justify-content-center">
            <div class="search-close-btn">+</div>
            <form class="search-model-form">
                <input type="text" id="search-input" placeholder="Searching key.....">
            </form>
        </div>
    </div>
    <!-- Search model end -->

    <!-- JS here -->

  
    


    <script src="./assets/js/vendor/modernizr-3.5.0.min.js"></script>
    <!-- Jquery, Popper, Bootstrap -->
    <script src="./assets/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="./assets/js/popper.min.js"></script>
    <script src="./assets/js/bootstrap.min.js"></script>
    <!-- Jquery Mobile Menu -->
    <script src="./assets/js/jquery.slicknav.min.js"></script>

    <!-- Jquery Slick , Owl-Carousel Plugins -->
    <script src="./assets/js/owl.carousel.min.js"></script>
    <script src="./assets/js/slick.min.js"></script>

    <!-- One Page, Animated-HeadLin -->
    <script src="./assets/js/wow.min.js"></script>
    <script src="./assets/js/animated.headline.js"></script>
    <script src="./assets/js/jquery.magnific-popup.js"></script>

    <!-- Scrollup, nice-select, sticky -->
    <script src="./assets/js/jquery.scrollUp.min.js"></script>
    <script src="./assets/js/jquery.nice-select.min.js"></script>
    <script src="./assets/js/jquery.sticky.js"></script>
    
    <!-- contact js -->
    <script src="./assets/js/contact.js"></script>
    <script src="./assets/js/jquery.form.js"></script>
    <script src="./assets/js/jquery.validate.min.js"></script>
    <script src="./assets/js/mail-script.js"></script>
    <script src="./assets/js/jquery.ajaxchimp.min.js"></script>
    
    <!-- Jquery Plugins, main Jquery -->    
    <script src="./assets/js/plugins.js"></script>
    <script src="./assets/js/main.js"></script>
    
</body>
</html>