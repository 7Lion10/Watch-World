<?php 
include '../config.php';
$Admin = new Admin();

    $username =$_POST['username'];
    $password =$_POST['password'];
    $email =$_POST['email'];
    $fullname =$_POST['fullname'];

    $address =$_POST['address'];
    $contact =$_POST['contact'];


    $targetdir='upload/';
    $image=$targetdir.basename($_FILES['image']['name']);
    move_uploaded_file($_FILES['image']['tmp_name'], $image);


    
    $stmt=$Admin->cud("INSERT INTO `customer` (`username`,`password`,`c_name`,`email`,`address`,`contact`,`image`)
        VALUES('$username','$password','$fullname','$email','".addslashes($address)."','$contact','$image')","Saved");


     echo "<script>alert('Registered successfully');window.location='../login/login.php';</script>";

?>