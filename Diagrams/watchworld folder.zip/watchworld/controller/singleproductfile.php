<?php 
include '../config.php';
$admin = new Admin();

$id =$_POST['p_id']; 

  ?>