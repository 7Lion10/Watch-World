<?php 
include '../config.php';
$Admin = new Admin();

    $message =$_POST['message'];
    $email =$_POST['email'];
    
    $cid =$_POST['cid'];
    $sid =$_POST['sid'];
    $status='pending';
    

    


    
    $stmt=$Admin->cud("INSERT INTO `requests` (`request`,`c_id`,`s_id`,`email`,`date`,`r_status`)
        VALUES('".addslashes($message)."','$cid','$sid','$email',now(),'$status')","Saved");


     echo "<script>alert('Request sent successfully');window.location='../viewrequest.php';</script>";

?>