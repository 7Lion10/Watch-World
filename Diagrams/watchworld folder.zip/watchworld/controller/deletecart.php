<?php
include '../config.php';
$admin =new Admin();
$id=$_GET['id'];
$stmt =$admin->cud("DELETE FROM `cart` WHERE `cart_id`='$id'","Deleted"); 
echo "<script>alert('Deleted successfully');window.location='../viewcart.php';</script>";








?>