<?php 
include '../config.php';

$admin=new Admin();

$id=$_SESSION['c_id'];



	$name=$_POST['fullname'];
	$email=$_POST['email'];
	$address=$_POST['address'];
	$contact=$_POST['contact'];

	

$stmt=$admin->cud("UPDATE `customer` SET `c_name`='$name',`email`='$email',`address`='$address',`contact`='$contact' WHERE `c_id`='$id'","updated");

echo "<script>alert(' Profile updated');window.location='../profile.php';</script>";





?>