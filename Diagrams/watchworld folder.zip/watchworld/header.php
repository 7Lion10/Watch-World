<?php 
include 'config.php';
$admin = new Admin();




?>

<div class="header-area">
            <div class="main-header header-sticky">
                <div class="container-fluid">
                    <div class="menu-wrapper">
                        <!-- Logo -->
                        <div class="logo">
                            <a href="index.php"><img src="assets/img/logo/logo_1.png" alt=""></a>
                            <!-- <span><h1>Watch</h1><h1 style="color:red;">World</h1></span> -->

                        </div>
                        <!-- Main-menu -->
                        <div class="main-menu d-none d-lg-block">
                            <nav>                                                
                                <ul id="navigation">  
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="about.php">About</a></li>
                                    <li><a href="blog.php">Blog</a></li>
                                    <li><a href="feedback.php">Feedback</a></li>
                                    <li><a href="products.php">Products</a></li>

                               <?php 
                               if (!isset($_SESSION['c_id'])) {?>
                                
                                    <li>
                                    <a href="#">Login</a>
                                        <ul class="submenu">
                                            <li><a href="admin/login/login.php">Admin</a></li>
                                            <li><a href="login/login.php">Customer</a></li>
                                            <li><a href="shopowners/login/login.php">Shop owner</a></li>

                                        </ul>

                                    </li>
                                   
                                   <?php
                               }
                               else{?>

                                    <li>
                                    <a href="#">Service</a>
                                        <ul class="submenu">
                                            <li><a href="services.php">Request Service</a></li>
                                            <li><a href="viewrequest.php">View Request</a></li>
                                            

                                        </ul>

                                    </li>

                                    
                                

                                <li><a href="logout.php" onclick="return confirm('Do you want to Logout?')">Logout</a></li>
                                <?php 
                               }
                                ?>
                                     
                                </ul>


                            </nav>
                        </div>
                        <!-- Header Right -->
                        <div class="header-right"style="margin-right: 15px;">
                            <ul>
                                <!-- <li>
                                    <div class="nav-search search-switch">
                                        <span class="flaticon-search"></span>
                                    </div>
                                </li> -->
                                <li> <a href="profile.php"><span class="flaticon-user"></span></a></li>
                                <li><a href="viewcart.php"><span class="flaticon-shopping-cart"></span></a> </li>
                            </ul>
                        </div>
                    </div>
                    <!-- Mobile Menu -->
                    <div class="col-12">
                        <div class="mobile_menu d-block d-lg-none"></div>
                    </div>
                </div>
            </div>
        </div>